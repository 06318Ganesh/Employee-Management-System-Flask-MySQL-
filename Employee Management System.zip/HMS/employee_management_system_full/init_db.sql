DROP DATABASE IF EXISTS employee_system;
CREATE DATABASE employee_system;
USE employee_system;

CREATE TABLE Employees(
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id VARCHAR(50) UNIQUE,
    name VARCHAR(150),
    password VARCHAR(255),
    email VARCHAR(150),
    phone VARCHAR(30),
    role VARCHAR(20),
    location VARCHAR(100),
    blood_group VARCHAR(10),
    gender VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin account (employee_id: ADMIN001, password: admin123)
INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('ADMIN001','System Admin','$2b$12$TeIhvWaOIpc/pfEdLnqOwO9LdG.eWP18U4u7UQJ3Md3iI0Re9MyFa','admin@company.com','9999999999','admin','HQ','O+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP001','Rohan Kumar','$2b$12$iW13/N9Ru1VFO7RsNpdOCemwTW40uOKvTxEOHC0Chri5NUCKapNue','rohan1@example.com','9876543211','employee','Mumbai','O+','Female');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP002','Priya Sharma','$2b$12$.kFqcVFB.GHk72tM3ztl.eAga.apBnIMg0hpf2dAi6r1ykIyD8fKe','priya2@example.com','9876543212','employee','Pune','O-','Female');

INSERT INTO Employees(employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP003','Kiran Reddy','$2b$12$drkZB3b7yEHkmxbsRYtVve.HDKh3UgLfrhIw0otcocdAU6zBrdtF6','kiran3@example.com','9876543213','employee','Vizag','B+','Female');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP004','Sneha Gupta','$2b$12$AkHRs7NpR8LgwclhRmT.se8jwY/PMjSHwTzpfMRCpOR19wN6jiO5.','sneha4@example.com','9876543214','employee','Bangalore','A-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP005','Vamsi Krishna','$2b$12$CuIasmgiaLPrGcjaZn.8JuREJi1b8FHfocAz75nFLtOGQ0yH5tJKm','vamsi5@example.com','9876543215','employee','Vizag','B-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP006','Harika Rao','$2b$12$XA/6AbuEt15a8QA5ZCJhsuDPjh0uXxmWEp2.JpIIUa9M8L6UZIg62','harika6@example.com','9876543216','employee','Pune','AB+','Female');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP007','Manoj R','$2b$12$oOQnxvHFkDKxdVfyWSkgC.3G8UD2smpMd86JI5SrHIiJgj7OcfRdW','manoj7@example.com','9876543217','employee','Chennai','O+','Female');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP008','Chaitanya P','$2b$12$sZrsDYwBtsoz8QvcxHZ41e0el4tjoPUwBaLOGt/yJiAZoYQoKXqaq','chaitanya8@example.com','9876543218','employee','Vizag','B-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP009','Lavanya S','$2b$12$mJN14HnozLQwHIn8qgP0c.AgXPql./zVti.QXrpJVJjRje0Mj5PPu','lavanya9@example.com','9876543219','employee','Pune','O+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP010','Rakesh B','$2b$12$gQrh6BjBB4C4m1hbwT6.duuIw9HnNdPMhSgTB3/vPoYT1h.Fv57pm','rakesh10@example.com','9876543220','employee','Pune','O-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP011','Tarun K','$2b$12$O.OVx4wLNTB9.H.6RX2pR.wb2s0F1qxyYRXoX./.4/Z0pkqwtWrUe','tarun11@example.com','9876543221','employee','Bangalore','AB+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP012','Sravani M','$2b$12$ler..SwrDHWpBBGSo9YaN.JN/YbD5jKaEig8dpEuaFcZtcUlgbHOu','sravani12@example.com','9876543222','employee','Kolkata','O-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP013','Gowtham R','$2b$12$aGw8wUVZmnfPOI8qcDNOVOy4hl92G/IISIYH28uxNlCKRlenLuape','gowtham13@example.com','9876543223','employee','Vizag','O-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP014','Meghana S','$2b$12$1pychGWlhPErFahUVLQz7ejeFfSe4hr4aD96ErKEMUErnoPx5Vewi','meghana14@example.com','9876543224','employee','Vizag','AB+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP015','Krishna V','$2b$12$ID8r36m1pvqt2vZXSKHH7eFO3xFZSF2.WA8K7C/A8hg338fsst/EW','krishna15@example.com','9876543225','employee','Kolkata','O+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP016','Anusha K','$2b$12$a1.0xYvvNfId.hgqfaz8eOqXjWxN3lxI5E1Z5I3WE1cp9rKVt8n.e','anusha16@example.com','9876543226','employee','Pune','O+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP017','Ravi Teja','$2b$12$.BtrvPdrHzZyRwK1JSAnP.WlXlqfpdGwn8RtuZdA02rCjM..js6se','ravi17@example.com','9876543227','employee','Mumbai','A-','Female');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP018','Deepika S','$2b$12$AQGtKDHsRwS3Z3mRIYw66./1aHhkjsgf35KUSELwLRL.sF7CGn5si','deepika18@example.com','9876543228','employee','Bangalore','AB-','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP019','Ajay Kumar','$2b$12$SbXyuCciPwN7QakmXGo8P.XGGGuIQ0ZTlfKUYubkmvQzhf6kt7Ys.','ajay19@example.com','9876543229','employee','Hyderabad','O+','Male');

INSERT INTO Employees (employee_id, name, password, email, phone, role, location, blood_group, gender)
VALUES ('EMP020','Aishwarya','$2b$12$eersQhV6si4mEHqS6/Eo.uc07VPkpMG2tXqTAOgOK14pmZXj.qi1.','aishwarya20@example.com','9876543230','employee','Hyderabad','B-','Male');
