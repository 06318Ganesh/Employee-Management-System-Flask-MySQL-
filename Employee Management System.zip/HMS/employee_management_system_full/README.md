# Employee Management System (Flask + MySQL)

## What is included
- Flask backend (app.py)
- Database helper (db.py)
- SQL initialization script (init_db.sql) with an admin account and 20 sample employees
- Templates for login, admin dashboard, add employee, employee dashboard, and profile
- Static CSS for basic styling
- requirements.txt and .env.example

## Quick setup (local)
1. Install Python 3.10+ and MySQL.
2. Create a virtual environment and activate it:
   ```bash
   python -m venv venv
   source venv/bin/activate   # (Windows: venv\Scripts\activate)
   ```
3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
4. Create the database and seed data:
   ```bash
   mysql -u root -p < init_db.sql
   ```
   The SQL file contains:
   - Admin: employee_id = ADMIN001, password = admin123
   - 20 employees: EMP001..EMP020 with simple passwords (listed below)

Sample employees and plain passwords (for testing):
- EMP001 : pass001 (name: Rohan Kumar)\n- EMP002 : pass002 (name: Priya Sharma)\n- EMP003 : pass003 (name: Kiran Reddy)\n- EMP004 : pass004 (name: Sneha Gupta)\n- EMP005 : pass005 (name: Vamsi Krishna)\n- EMP006 : pass006 (name: Harika Rao)\n- EMP007 : pass007 (name: Manoj R)\n- EMP008 : pass008 (name: Chaitanya P)\n- EMP009 : pass009 (name: Lavanya S)\n- EMP010 : pass010 (name: Rakesh B)\n- EMP011 : pass011 (name: Tarun K)\n- EMP012 : pass012 (name: Sravani M)\n- EMP013 : pass013 (name: Gowtham R)\n- EMP014 : pass014 (name: Meghana S)\n- EMP015 : pass015 (name: Krishna V)\n- EMP016 : pass016 (name: Anusha K)\n- EMP017 : pass017 (name: Ravi Teja)\n- EMP018 : pass018 (name: Deepika S)\n- EMP019 : pass019 (name: Ajay Kumar)\n- EMP020 : pass020 (name: Aishwarya)\n

5. Create a `.env` by copying `.env.example` and updating MYSQL_PASSWORD.
6. Run the Flask app:
   ```bash
   python app.py
   ```
7. Open http://127.0.0.1:5000

## Notes
- Passwords are stored as bcrypt hashes in the DB.
- For production, set a strong SECRET_KEY and secure DB credentials.
