
from flask import Flask, render_template, request, redirect, session, flash, url_for
from db import get_connection
from dotenv import load_dotenv
import os, bcrypt

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'change-me')

# -------------------- Home Page --------------------
@app.route('/')
def index():
    return render_template('index.html')

# -------------------- Login --------------------
@app.route('/login', methods=['POST'])
def login():
    emp_id = request.form.get('employee_id').strip()
    password = request.form.get('password')
    role = request.form.get('role')

    db = get_connection()
    cur = db.cursor(dictionary=True)

    if role == 'admin':
        cur.execute("SELECT * FROM Employees WHERE employee_id=%s AND role='admin'", (emp_id,))
    else:
        cur.execute("SELECT * FROM Employees WHERE employee_id=%s AND role='employee'", (emp_id,))

    user = cur.fetchone()
    cur.close()
    db.close()

    if user and bcrypt.checkpw(password.encode(), user['password'].encode()):
        session['user_id'] = user['id']
        session['role'] = user['role']
        session['employee_id'] = user['employee_id']

        if role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('employee_dashboard'))

    flash('Invalid credentials', 'danger')
    return redirect(url_for('index'))

# -------------------- Admin Dashboard --------------------
@app.route('/admin/dashboard')
def admin_dashboard():
    if session.get('role') != 'admin':
        return redirect(url_for('index'))

    db = get_connection()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Employees WHERE role='employee' ORDER BY id")
    employees = cur.fetchall()
    cur.close()
    db.close()
    return render_template('admin_dashboard.html', employees=employees)

# -------------------- Add Employee --------------------
@app.route('/admin/add', methods=['GET','POST'])
def admin_add():
    if session.get('role') != 'admin':
        return redirect(url_for('index'))

    if request.method == 'POST':
        emp_id = request.form.get('employee_id').strip()
        name = request.form.get('name').strip()
        password = request.form.get('password')
        email = request.form.get('email')
        phone = request.form.get('phone')
        location = request.form.get('location')
        blood = request.form.get('blood_group')
        gender = request.form.get('gender')

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        db = get_connection()
        cur = db.cursor()
        cur.execute("""INSERT INTO Employees 
                       (employee_id, name, password, email, phone, role, location, blood_group, gender)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (emp_id, name, hashed, email, phone, 'employee', location, blood, gender))
        db.commit()
        cur.close()
        db.close()

        flash('Employee added', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('add_employee.html')

# -------------------- Employee Dashboard --------------------
@app.route('/employee/dashboard')
def employee_dashboard():
    if session.get('role') != 'employee':
        return redirect(url_for('index'))

    emp_id = session.get('employee_id')
    db = get_connection()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Employees WHERE employee_id=%s", (emp_id,))
    user = cur.fetchone()
    cur.close()
    db.close()

    return render_template('employee_dashboard.html', user=user)

# -------------------- Employee Profile --------------------
@app.route('/employee/profile')
def employee_profile():
    if session.get('role') != 'employee':
        return redirect(url_for('index'))

    emp_id = session.get('employee_id')
    db = get_connection()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Employees WHERE employee_id=%s", (emp_id,))
    user = cur.fetchone()
    cur.close()
    db.close()

    return render_template('employee_profile.html', user=user)

# -------------------- Logout --------------------
@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
