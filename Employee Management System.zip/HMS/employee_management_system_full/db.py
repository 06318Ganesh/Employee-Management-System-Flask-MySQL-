import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

def get_connection():
    return mysql.connector.connect(
        host=os.getenv('MYSQL_HOST', 'localhost'),
        user=os.getenv('MYSQL_USER', 'root'),
        password=os.getenv('MYSQL_PASSWORD', '0880'),
        database=os.getenv('MYSQL_DB', 'employee_system'),
        port=int(os.getenv('MYSQL_PORT', 3306)),
        auth_plugin='mysql_native_password'  
    )
